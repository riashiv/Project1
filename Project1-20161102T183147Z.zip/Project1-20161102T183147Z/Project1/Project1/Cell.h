/*
* Name : Ria Shiv
* File : Cell.h
* Date : 30th October 2016
*/
#pragma once
#ifndef CELL_H
#define CELL_H
#include <cstdlib>
class Cell
{

public:
	int value;			//value of cell impt
	Cell(int aval, bool aisRed)		//contructor
	{
		value = aval;
		isRed = aisRed;
	}
	Cell()					//assigns random bumber to cell btw 0 - 37
	{
		value = rand() % 37 + 0;
	}
	bool isEven();				//checks if its ODD or EVEN
	bool isRed;					//checks if its RED or BLACk
	bool isZeroOrDoubleZero();	//checks if the number is 0 or 37
	int getValue();				//returns value of cell
	int getRow();				//returns the row 

};
#endif

