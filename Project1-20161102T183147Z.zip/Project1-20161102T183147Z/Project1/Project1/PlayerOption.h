/*
* Name : Ria Shiv
* File : PlayerOption.h
* Date : 30th October 2016
*/
#pragma once

#include<string>
#include<iostream>
#include<set>
#include "Cell.h"


using namespace std;

class PlayerOption
{
private:
	int betTypeId, betOption; //stores the type of bet and what is betted on
	int wager, winnings; //stores the amount of money betted and money won 

	enum BetType { EVEN_ODD = 1, RED_BLACK = 2, NUMBER = 3, ONE_THIRD = 4 }; //enum for type of bet
	enum BetEvenOddOpt { ODD = 1, EVEN = 2 }; //enum for odd and even
	enum BetRedBlackOpt { RED = 1, BLACK = 2, }; //enum for red and black option
	enum BetSetsOpt { OT_1_12 = 1, OT_13_24 = 2, OT_25_36 = 3 }; // ONE_THIRD

	void evaluateRedBlack(Cell* cell);	// to evaluate red and black type bet
	void evaluateOddEven(Cell* cell);	// to evaluate odd and even type bet
	void evaluateSingleNumber(Cell* cell); //to evaluate single number bet 
	void evaluateOneThird(Cell* cell); //to evaluate one third bet 


public:
	void displayOptions(); //displays the menu on the bet option for each type of bet 
	void isValidOption(); //checks if the options inputted are valid or not 
	void evaluateBet(Cell* cell); // sees which type of bet is made to call the specific function 
	int winningAmount();	//returns the amount won 
	void showAnalytics(Cell* cell); //shows the analytics of the bets 
	bool isWinner;			//stores a bool value depending uponn if the person won or not 
	string selectedBet();	//assigns value to the bet selected depending on the type 
	void setWager(int amount);//sets value to the wager variable 

	PlayerOption(int _betTypeId) { //contructor
		betTypeId = _betTypeId;
		betOption = 0;
		wager = 0;
		winnings = 0;
	}
	PlayerOption(int _betTypeId, int _betOption) { //overloaded constructor 
		betTypeId = _betTypeId;
		betOption = _betOption;
		wager = 0;
		winnings = 0;
	}
};
