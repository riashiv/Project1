/*
* Name : Ria Shiv
* File : Game.cpp
* Date : 30th October 2016
*/
#include "Cell.h"
#include <map>
#include "Game.h"
// rolls the ball to find a random number and assigns it to currentBallPosition
void Game::rollBall()
{
	currentBallPosition = randomNumner(1, 36);
}
// returns a random number 
int Game::randomNumner(int low, int high) {
	srand(time(NULL)); //seed value

	if (low > high) return high;
	return low + (std::rand() % (high - low + 1));
}

//returns the value of the cell position at the currentBallPosition 
Cell* Game::cellAtBallPosition()
{
	std::map<int, Cell*>::iterator it;
	it = cellMap.find(currentBallPosition);
	return it->second;
}