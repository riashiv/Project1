/*
 * Name : Ria Shiv 
 * File : PlayerOption.cpp
 * Date : 30th October 2016
 */
#include "PlayerOption.h"
#include<stdlib.h>

//called to evaluate bet on the cell 
void PlayerOption::evaluateBet(Cell* cell){
	switch (betTypeId){ //the corresponding evaluate bet function is called based on the type of bet 
	case RED_BLACK:	 //for red black bet 
		evaluateRedBlack(cell);
		break;
	case EVEN_ODD: // for odd and even bet 
		evaluateOddEven(cell);
		break;
	case NUMBER:	// for single number bet 
		evaluateSingleNumber(cell);
	case ONE_THIRD:	//for one third row bet 
		evaluateOneThird(cell);
		break;
	}
}

//Callled when the betting type is red black
void PlayerOption::evaluateRedBlack(Cell* cell){
	switch (betOption){
	case RED: 
		isWinner = cell->isRed; 
		break;
	case BLACK: 
		isWinner = !cell->isRed;
		break;
	}
	winnings = isWinner ? wager * 2 : 0; //winning is given value based on isWinner
}

//called when the bet is an odd and even type 
void PlayerOption::evaluateOddEven(Cell* cell){
	switch (betOption){
	case EVEN:
		isWinner = cell->isEven();
		break;
	case ODD:
		isWinner = !cell->isEven();
		break;
	}
	winnings = isWinner ? wager * 2 : 0; //winning is given value based on isWinner
}

//called when the bet is single number type 
void PlayerOption::evaluateSingleNumber(Cell* cell){
	if (betOption == cell->getValue())
		isWinner = true;
	else
		isWinner = false; 
	winnings = isWinner ? (wager * 36) : 0; //winning is given value based on isWinner 
}

//called when the bet is on one third of the row 
void PlayerOption::evaluateOneThird(Cell* cell){
	switch (betOption)
	{
	case OT_1_12:
		isWinner = cell->getValue() >= 1 && cell->getValue() <= 12;
		break;
	case OT_13_24:
		isWinner = cell->getValue() >= 13 && cell->getValue() <= 24;
		break;
	case OT_25_36:
		isWinner = cell->getValue() >= 25 && cell->getValue() <= 36;
		break;
	}
	winnings = isWinner ? wager * 3 : 0; //winnings is given the amount based on the value of isWinner
}

//returns the winning amount
int PlayerOption::winningAmount(){
	return winnings;
}

//displays the option of bets that should have been chosen for each  type 
void PlayerOption::displayOptions(){
	switch (betTypeId)
	{
	case EVEN_ODD:
		cout << "\nChoose 1 for ODD or 2 for EVEN: ";	
		break;
	case RED_BLACK:
		cout << "\nChoose 1 for RED or 2 for BLACK: ";
		break;
	case NUMBER:
		cout << "\nEnter a number between 1-36: ";
		break;
	case ONE_THIRD:
		cout << "\nCHOOSE 1 for 1-12, 2 for 13-24 OR 3 for 25-36: ";
		break;
	}
	while (betOption == 0){
		cin >> betOption;
		isValidOption();		//checks for the validity of the option exception handler
	}
}

void PlayerOption::isValidOption(){		//checks if the option entered is valid or not 
	bool isError = false;
	switch (betTypeId)
	{
	case EVEN_ODD:
	case RED_BLACK:
		isError = betOption != 1 && betOption != 2;
		break;
	case ONE_THIRD:
		isError = betOption != 1 && betOption != 2 && betOption != 3;
		break;
	case NUMBER:
		isError = betOption < 1 || betOption > 36;
		break;
	}
	if (isError){			//error displayed when it is not valid 
		cout << "@@@@ Error: Please select valid option: ";
		betOption = 0;
	}
}

//This assign the value to the betOption basd on various betting types 
string PlayerOption::selectedBet(){
	switch (betTypeId)
	{
	case EVEN_ODD:
		return betOption == 1 ? "ODD" : "EVEN";
		break;
	case RED_BLACK:
		return betOption == 1 ? "RED" : "BLACK";
		break;
	case NUMBER:
		return to_string(betOption);
		break;
	case ONE_THIRD:
		return betOption == 1 ? "1-12" : (betOption == 2 ? "13-24" : "25-36");
		break;
	}
	return "";
}

//sets the value to the wager
void PlayerOption::setWager(int amount){
	wager = amount;
}

//shows the analytics of the historical plays 
void PlayerOption::showAnalytics(Cell* cell){
	cout << "\n" << "Bet on : $" + to_string(wager) + " on " << selectedBet() + "\t" << "Ball rolled: " << (cell->getValue()) <<(cell->isRed ? " (R)" : " (B)") << "\t";
	cout << "You " << (isWinner ? "WON\t" : "LOST") << "\tWinning Amount: " << winningAmount();
}