/*
* Name : Ria Shiv
* File : Player.h
* Date : 30th October 2016
*/
#pragma once
#ifndef PLAYER_H
#define PLAYER_H
#include<string>
#include<iostream>
#include <list>
#include"PlayerPlay.h"
#include"Game.h"

using namespace std;

class Player
{

private:
	string name; //To store the name of the player
	int balance; //To store current balance
	int betId;   //To store the type of bet 
	std::list<PlayerPlay*> playPlayerList; //stores historical plays 
	std::list<PlayerPlay*>::iterator playPlayerIt; // used to iterate through the playerPlaylist
	Game *game;
public:
	void setName(); //to set the name of the player
	void play(); //called to play the game when the player plays the first time
	void play(PlayerPlay* playerPlay); //called every other time the layer plays the game
	void playComputer();				// called when the player opts for the computer to play
	void chooseOption();				//chooses option on which type of bet is done
	void showAnalytics();				//shows the history of all the play
	int getBalance();					//returns the balance left
	PlayerPlay* computerPlayerPlay(int amount, int inputBet, int inputBetOption); //called when opted for the computer to play 
	Player(string aname, int abalance, Game *agame)		//player constructor 
	{
		name = aname;
		balance = abalance;
		game = agame;
	}
};

#endif