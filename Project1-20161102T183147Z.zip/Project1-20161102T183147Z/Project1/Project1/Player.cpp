/*
* Name : Ria Shiv
* File : Player.cpp
* Date : 30th October 2016
*/
#include "Player.h"
#include<stdlib.h>
#include<ctime>

//called when the computer is opted to play
void Player::playComputer() {
	int i = 0;
	cout << "***** Starting Balance : $" << balance;
	
	while (i < 1000) {
		PlayerPlay *playerPlay = NULL;
		int modVal = i % 4;			//chooses a number btw 0-3 based on i
		if (modVal == 0) {
			int choice = game->randomNumner(1, 2);
			playerPlay = computerPlayerPlay(10, 1, choice); // Play ODD EVEN
		}
		else if (modVal == 1) {
			int choice = game->randomNumner(1, 2);
			playerPlay = computerPlayerPlay(10, 2, choice); // Play Red Black
		}
		else if (modVal == 2) {
			int choice = game->randomNumner(1, 3);
			playerPlay = computerPlayerPlay(10, 4, choice); // Play One Third
		}
		else {
			int choice = game->randomNumner(1, 36);
			playerPlay = computerPlayerPlay(10, 3, choice); // Play Number
		}
		play(playerPlay); //called to play the game
		playPlayerList.insert(playPlayerList.end(), playerPlay); 
		i += 1;
		if (balance < 10) {
			break;
		}
	}
	showAnalytics(); //shows the histroy of the play
	cout << "\n\n***** Balance at the end of game : $" << balance;

}

// computer player is called and the object is intialized with amount the betting amount and option 
PlayerPlay* Player::computerPlayerPlay(int amount, int inputBet, int inputBetOption) {
	PlayerPlay* playerPlay = new PlayerPlay(amount, inputBet);
	playerPlay->inputBallBet(inputBetOption);
	return playerPlay;
}

//In this part the player chooses the option on which he wants to bet on 
void Player::chooseOption() {
	betId = 0;
	cout << "\n\nThere are 4 types of bet you can make \n";
	cout << "\t1. Choose Odd or Even\n";
	cout << "\t2. Choose RED or BLACK\n";
	cout << "\t3. Choose a single number between 1-36\n";
	cout << "\t4. Choose one third\n";
	cout << "\nPlease select type of bet: ";
	while (betId < 1 || betId > 4) {	//bet id is assigned with the exception being handled 
		cin >> betId;
	}

}

//this is callled to play the game 
void Player::play() {
	cout << "\n\n=======================================================";
	chooseOption(); //chooses option from the list
	PlayerPlay *playerPlay = new PlayerPlay(betId); //object of player play is created 
	playerPlay->setRemainingBal(balance); //balance is set 
	playerPlay->takeWager();	//this function makes the user assign the wager for the bet
	playerPlay->inputBallBet(); //bet on type is inputted 
	play(playerPlay);// called to play the real game 
	playPlayerList.insert(playPlayerList.end(), playerPlay);//inserts object on the memory list
	playerPlay->showAnalytics(); // shows betting info 
	cout << "\n=======================================================\n\n";
}

void Player::play(PlayerPlay* playerPlay) {
	balance = balance - playerPlay->getTotalWager();// the betting balance is subtracted 
	game->rollBall();// ball is rolled to a random position
	playerPlay->evaluateBet(game->cellAtBallPosition()); // the bet value is evaluated 
	balance = balance + playerPlay->winning(); // the winning amount is added
	playerPlay->setRemainingBal(balance);// the balance is set back 
}

//sets your name in the program
void Player::setName()
{
	cout << "Enter your name ";
	getline(cin, name);
}

//the list is displayed with all the values of the previous plays 
void Player::showAnalytics() {
	cout << "\n\n=================================================================================================";
	//iterates through the list 
	for (playPlayerIt = playPlayerList.begin(); playPlayerIt != playPlayerList.end(); ++playPlayerIt) {
		PlayerPlay* playerPlay = dynamic_cast<PlayerPlay*> (*playPlayerIt);
		playerPlay->showAnalytics(); //calls playerplay function using object
	}
	cout << "\n=================================================================================================\n\n";
}

//balance is returned 
int Player::getBalance() {
	return balance;
}
