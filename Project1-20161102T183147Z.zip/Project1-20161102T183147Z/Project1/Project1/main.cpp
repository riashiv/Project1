/*
* Name : Ria Shiv
* File : main.cpp
* Date : 30th October 2016
*/
//C++ libraies
#include <cstdlib>
#include <ctime>
#include <iostream>

//User made header files 
#include "Game.h"
#include"Player.h"
#include"PlayerPlay.h"
#include"Cell.h"
using namespace std;

//global functions 
bool playGame();
void playOptions();
void printGameTable();
void playComputer();
void play();
bool isQuit = false;

//main 
int main(int argc, char** argv) {
	if (playGame())			//checks if user wants too play the game 
	{
		printGameTable();		//prints the game table
		playOptions();			//prints the various options to play
		while (!isQuit) {		//quits the game when the user wants it to end

		}
	}
	else
	{
		cout << "THANK YOU!" << endl;
	}

}

//Called when the user wants to play the game by himself
void play() {
	string name;
	int balance;
	cout << "\nEnter your name: ";	//get user name
	while (name.empty()) {
		getline(cin, name);
	}
	cout << "Enter the amount of balance u want to play for : "; //get user balance
	cin >> balance;
	cout << "\n\n\t\tWelcome " << name << "! " << balance << " has been credited to your account.\n";
	Game *game = new Game(); // game object is created 
	Player *player = new Player(name, balance, game);  //player option is created 
	bool continueGame = true;
	char opt = 'Y';
	while (continueGame) {    // plays only until the user wants 
		if (opt == 'Y' || opt == 'y') {
			if (player->getBalance() < 1) {			//throws acception when the user is running out of money
				cout << "\n\nSorry! You are running out of balance, game cannot be continue";
			}
			else {
				player->play(); //called to play the game 
			}
		}
		else if (opt == 'S' || opt == 's') {
			player->showAnalytics();
		}		// the analytics of the game are shown with past history
		opt = 'N';
		cout << "\n\nDo you wish to continue ? \n\tPress Y to continue. \n\tPress S to view play history. \n\tAny other key to exit\n\n";
		cout << "Enter your option: ";
		cin >> opt;
		continueGame = opt == 'Y' || opt == 'y' || opt == 'S' || opt == 's';
		isQuit = !continueGame;
	}

}

//called when the computer wants to play 
void playComputer() {
	Game *game = new Game(); //game object is created 
	Player *player = new Player("Ria", 1000, game); // player object is created 
	player->playComputer(); // Computer object is created 
}

//displays the options on what the user wants to take 
void playOptions()
{
	cout << "This game has 2 options:\n";
	cout << "\t 1. Enter 1 to play\n";
	cout << "\t 2. Enter 2 to play by computer\n";
	cout << "\t 3. Press any other key to quit\n\n";
	cout << "Enter your option: ";

	int gameOption;
	cin >> gameOption;
	if (gameOption == 1) { // when the user wants to play 
		play();
	}
	else if (gameOption == 2) { // when the computer wants to play
		playComputer();
		isQuit = true; 
	}
	else {
		isQuit = true;
	}
}

//ask intially if the user wants to play the game 
bool playGame()
{
	system("cls");
	char ch;
	cout << "Do you want to play ?(Press Y for yes| Press any other key to quit) : ";
	cin >> ch;
	if (ch == 'Y' || ch == 'y')
		return true;
	return false;
}

//prints the table 
void printGameTable()
{
	cout << "\n************** ROULLETE TABLE *****************"
		<< "\n     ______________ ______________ _________ "
		<< "\n    |         |         |         |         |"
		<< "\n    |    1    |    2    |    3    |         |"
		<< "\n    |   (B)   |   (R)   |   (B)   |         |"
		<< "\n    |_________|_________|_________|         |"
		<< "\n    |         |         |         |         |"
		<< "\n    |    4    |    5    |    6    |         |"
		<< "\n    |   (R)   |   (B)   |   (R)   |         |"
		<< "\n    |_________|_________|_________|  1-12   |_________"
		<< "\n    |         |         |         |         |         |"
		<< "\n    |    7    |    8    |    9    |         |         |"
		<< "\n    |   (B)   |   (R)   |   (B)   |         |         | "
		<< "\n    |_________|_________|_________|         | *EVEN*  |"
		<< "\n    |         |         |         |         |         |"
		<< "\n    |    10   |    11   |    12   |         |         |"
		<< "\n    |   (R)   |   (B)   |   (R)   |         |         |"
		<< "\n    |_________|_________|_________|_________|_________|"
		<< "\n    |         |         |         |         |         |"
		<< "\n    |    13   |    14   |    15   |         |         |"
		<< "\n    |   (B)   |   (R)   |   (B)   |         |         |"
		<< "\n    |_________|_________|_________|         |  *RED*  |"
		<< "\n    |         |         |         |         |   (R)   |"
		<< "\n    |    16   |    17   |    18   |         |         |"
		<< "\n    |   (R)   |   (B)   |   (R)   |         |         |"
		<< "\n    |_________|_________|_________|  13-24  |_________|"
		<< "\n    |         |         |         |         |         |"
		<< "\n    |    19   |    20   |    21   |         |         |"
		<< "\n    |   (B)   |   (R)   |   (B)   |         |         |"
		<< "\n    |_________|_________|_________|         | *BLACK* |"
		<< "\n    |         |         |         |         |   (B)   |"
		<< "\n    |    22   |    23   |    24   |         |         |"
		<< "\n    |   (R)   |   (B)   |   (R)   |         |         |"
		<< "\n    |_________|_________|_________|_________|_________|"
		<< "\n    |         |         |         |         |         |"
		<< "\n    |    25   |    26   |    27   |         |         |"
		<< "\n    |   (B)   |   (R)   |   (B)   |         |         |"
		<< "\n    |_________|_________|_________|         |  *ODD*  |"
		<< "\n    |         |         |         |         |         |"
		<< "\n    |    28   |    29   |    30   |         |         |"
		<< "\n    |   (R)   |   (B)   |   (R)   |         |         |"
		<< "\n    |_________|_________|_________|  25-36  |_________|"
		<< "\n    |         |         |         |         |"
		<< "\n    |    31   |    32   |    33   |         |"
		<< "\n    |   (B)   |   (R)   |   (B)   |         |"
		<< "\n    |_________|_________|_________|         |"
		<< "\n    |         |         |         |         |"
		<< "\n    |    34   |    35   |    36   |         |"
		<< "\n    |   (R)   |   (B)   |   (R)   |         |"
		<< "\n    |_________|_________|_________|_________|\n\n";
}