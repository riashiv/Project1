/*
* Name : Ria Shiv
* File : PlayerPlay.h
* Date : 30th October 2016
*/
#pragma once
#ifndef PLAYERPLAY_H
#define PLAYERPLAY_H
#include "Cell.h"
#include "PlayerOption.h"
#include<set>
#include "Game.h"

using namespace std;
class PlayerPlay
{
	std::set<PlayerOption *> playerOptions; //a set of playerOptions is created 
public:
	int remainingBal;		//the balance left
	int moneyWon = 0;		//the money won during the bet	
	int wager = 0;			//the balance of the bet
	int choice;				//the type of bet used 
	Cell* cell;				//an object of cell is created 
	PlayerPlay(int _wager, int achoice)		//constructor
	{
		wager = _wager;
		moneyWon = 0;
		choice = achoice;
	}

	PlayerPlay(int achoice)			//overloaded contructor 
	{
		choice = achoice;
		moneyWon = 0;
		wager = 0;
	}
	void setRemainingBal(int amount);   //updates the amount of the balance
	void showAnalytics();			//used to show the historical plays 
	Cell* getWinningCell();			//returns the winning cell 
	void evaluateBet(Cell *winningCell); //iterates through the options to call the bet amount won 
	PlayerOption* inputBallBet(int betNumber); //this is used to enter the bet depending on the type 
	PlayerOption* inputBallBet();			//overloaded functions
	int getTotalWager();		//returns the total wager that users wants to bet 
	void takeWager();		//enters the wager from the user 
	int winning();		//returns the money won 
};

#endif
