/*
* Name : Ria Shiv
* File : Game.h
* Date : 30th October 2016
*/
#pragma once
#include<map>
#include<stdlib.h>
#include<set>
#include<ctime>
#include "Cell.h"
class Game
{
	std::map<int, Cell*> cellMap; // makes a cell map in the memory
	int currentBallPosition;	  //the position of the ball

public:
	void rollBall();				    // rolls the ball on the circle
	int randomNumner(int low, int high); //returns a random number 
	Cell* cellAtBallPosition();			//Finds the cell in the map
	//contrutor makes a map in the memory 
	Game()
	{
		cellMap.insert(std::pair<int, Cell*>(0, new Cell(0, false)));
		cellMap.insert(std::pair<int, Cell*>(1, new Cell(1, true)));
		cellMap.insert(std::pair<int, Cell*>(2, new Cell(2, false)));
		cellMap.insert(std::pair<int, Cell*>(3, new Cell(3, true)));
		cellMap.insert(std::pair<int, Cell*>(4, new Cell(4, false)));
		cellMap.insert(std::pair<int, Cell*>(5, new Cell(5, true)));
		cellMap.insert(std::pair<int, Cell*>(6, new Cell(6, false)));
		cellMap.insert(std::pair<int, Cell*>(7, new Cell(7, true)));
		cellMap.insert(std::pair<int, Cell*>(8, new Cell(8, false)));
		cellMap.insert(std::pair<int, Cell*>(9, new Cell(9, true)));
		cellMap.insert(std::pair<int, Cell*>(10, new Cell(10, false)));
		cellMap.insert(std::pair<int, Cell*>(11, new Cell(11, false)));
		cellMap.insert(std::pair<int, Cell*>(12, new Cell(12, true)));
		cellMap.insert(std::pair<int, Cell*>(13, new Cell(13, false)));
		cellMap.insert(std::pair<int, Cell*>(14, new Cell(14, true)));
		cellMap.insert(std::pair<int, Cell*>(15, new Cell(15, false)));
		cellMap.insert(std::pair<int, Cell*>(16, new Cell(16, true)));
		cellMap.insert(std::pair<int, Cell*>(17, new Cell(17, false)));
		cellMap.insert(std::pair<int, Cell*>(18, new Cell(18, true)));
		cellMap.insert(std::pair<int, Cell*>(19, new Cell(19, true)));
		cellMap.insert(std::pair<int, Cell*>(20, new Cell(20, false)));
		cellMap.insert(std::pair<int, Cell*>(21, new Cell(21, true)));
		cellMap.insert(std::pair<int, Cell*>(22, new Cell(22, false)));
		cellMap.insert(std::pair<int, Cell*>(23, new Cell(23, true)));
		cellMap.insert(std::pair<int, Cell*>(24, new Cell(24, false)));
		cellMap.insert(std::pair<int, Cell*>(25, new Cell(25, true)));
		cellMap.insert(std::pair<int, Cell*>(26, new Cell(26, false)));
		cellMap.insert(std::pair<int, Cell*>(27, new Cell(27, true)));
		cellMap.insert(std::pair<int, Cell*>(28, new Cell(28, false)));
		cellMap.insert(std::pair<int, Cell*>(29, new Cell(29, false)));
		cellMap.insert(std::pair<int, Cell*>(30, new Cell(30, true)));
		cellMap.insert(std::pair<int, Cell*>(31, new Cell(31, false)));
		cellMap.insert(std::pair<int, Cell*>(32, new Cell(32, true)));
		cellMap.insert(std::pair<int, Cell*>(33, new Cell(33, false)));
		cellMap.insert(std::pair<int, Cell*>(34, new Cell(34, true)));
		cellMap.insert(std::pair<int, Cell*>(35, new Cell(35, false)));
		cellMap.insert(std::pair<int, Cell*>(36, new Cell(36, true)));
		cellMap.insert(std::pair<int, Cell*>(37, new Cell(37, false)));
	}

};
