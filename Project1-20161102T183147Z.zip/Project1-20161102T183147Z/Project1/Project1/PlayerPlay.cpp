/*
* Name : Ria Shiv
* File : PlayerPlay.cpp
* Date : 30th October 2016
*/
#include<iostream>
#include "PlayerPlay.h"

using namespace std;

//makes the user enter the wager to bet 
void PlayerPlay::takeWager()
{
	cout << "\nEnter the bet amount: ";
	while (wager == 0) {
		cin >> wager;
		if (wager > remainingBal) { //handles exception if the bet is greater than the balance
			wager = 0;
			cout << "\n@@@Error:: Not enough balance. Current balance is $" << remainingBal << "\n";
		}
	}
}

//returns the money won 
int PlayerPlay::winning() 
{
	return moneyWon;
}

//evaluates the bet if the person won or not 
void PlayerPlay::evaluateBet(Cell *winningCell)
{
	cell = winningCell;
	std::set<PlayerOption *>::iterator it;
	for (it = playerOptions.begin(); it != playerOptions.end(); ++it) //iterates through the options
	{
		PlayerOption *playerOption = dynamic_cast<PlayerOption*>(*it); 
		playerOption->evaluateBet(winningCell); //the winning cell is passed to evaluate the bet in playerOptions 
		moneyWon += playerOption->winningAmount();
	}
}

//returns the wager of the bet 
int PlayerPlay::getTotalWager()
{
	return wager;
}

//sets the value of the bet depending on the type 
PlayerOption* PlayerPlay::inputBallBet(int number) {
	PlayerOption* playerOption = new PlayerOption(choice, number); //passes the number to playerOptions
	playerOption->setWager(wager);
	playerOptions.insert(playerOption);
	return playerOption;
}

//overloaded function that ask the user for the type of bet the user wants  
PlayerOption* PlayerPlay::inputBallBet() {
	PlayerOption* playerOption = new PlayerOption(choice);
	playerOption->displayOptions(); //ask the user to enter the type of bet
	playerOption->setWager(wager);
	playerOptions.insert(playerOption);
	return playerOption;
}

//returns the winning cell 
Cell* PlayerPlay::getWinningCell() {
	return cell;
}

//represents the historical plays
void PlayerPlay::showAnalytics() {
	std::set<PlayerOption *>::iterator it;
	for (it = playerOptions.begin(); it != playerOptions.end(); ++it)//iterates through the options 
	{
		PlayerOption* playerOption = dynamic_cast<PlayerOption*>(*it);
		playerOption->showAnalytics(getWinningCell());
		cout << "\tBalance: " << remainingBal;
	}
}

//updates the balance that remains after each play
void PlayerPlay::setRemainingBal(int amount) {
	remainingBal = amount;
}


