/*
* Name : Ria Shiv
* File : Cell.cpp
* Date : 30th October 2016
*/
#include "Cell.h"

//checks if the cell is odd or even
bool Cell::isEven()
{
	return value % 2 == 0;

}

//Checks if the number is 0 or 37
bool Cell::isZeroOrDoubleZero()
{
	if (value == 0 || value == 37)
	{
		return false;
	}
	return true;
}

//returns the cell value
int Cell::getValue()
{
	return value;
}

//returns the value of row for the one -third 
int Cell::getRow()
{
	if (value >= 1 && value <= 12)
		return 1;
	else if (value > 12 && value <= 24)
		return 2;
	else
		return 3;
}